from flask import Flask, render_template, url_for,Response, request,flash, redirect, url_for
import os
import time, threading
from datetime import datetime,timedelta,date
import numpy as np

from recognition_db import Db

from werkzeug.utils import secure_filename
import uuid

UPLOAD_FOLDER = '/uploads'
ALLOWED_EXTENSIONS = set(['png', 'jpg', 'jpeg'])


# db=Db()

app = Flask(__name__)

app.secret_key = 'super secret key'
app.config['SESSION_TYPE'] = 'filesystem'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER



persons=[]
checkList=[]
selectPerson=['','user','','','','','','']
visitors=[]
selectVisitor=('','','','','','','','','','')
search_result="user"
@app.route("/")
@app.route("/index")
def index():
    return render_template('index.html',)


@app.route("/common")
def common():
    return render_template('common.html', title='common')

@app.route("/log_details")
def log_details():
    return render_template('log_details.html', title='log-details')

@app.route("/login")
def login():
    return render_template('login.html', title='login')

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS
@app.route("/search_visitor", methods=['GET', 'POST'])
def search_visitor():
    global persons,checkList,selectPerson,personDetails,search_result
    
    personDetails=[]
    
    if request.method == 'POST':

        # print(request.form.getlist('checked'))
        if request.form['action']=="Search":
            
            # check if the post request has the file part
            if 'file' not in request.files:
                flash('No file part')
            else:
                file = request.files['file']
                # if user does not select file, browser also
                # submit a empty part without filename
                if file.filename == '':
                    flash('No selected file')
                    
                elif file and allowed_file(file.filename):
                    filename = secure_filename(file.filename)
                    file.save("search.png")
                    # rec=Recognition()
                    # searchIds,filename=rec.search_by_image("search.png")

                    db=Db()
                    pt=db.get_list_of_persons(searchIds)
                    
                    persons=[]
                    for p in pt:
                        pl=list(p)
                        pl[3]=datetime.fromtimestamp(pl[3])
                        pl[4]=datetime.fromtimestamp(pl[4])
                        persons.append(pl)
                    personDetails=[]
                    selectPerson=('','user','','','','','','')
                    search_result=filename        

        elif request.form['action']:
            db=Db()

            selectPerson=persons[int(request.form['action'])-1]
            pt=db.select_person_details_by_person_id(selectPerson[1])            
            

            personDetails=[]
            for p in pt:
                pl=list(p)
                pl[4]=datetime.fromtimestamp(pl[4])
                pl[5]=datetime.fromtimestamp(pl[5])
                dur=pl[5]-pl[4]
                pl[6]=str(timedelta(seconds=dur.seconds))
                personDetails.append(pl)
        

        # print(selectPerson)
            # print(request.form['action'])
        # print("checked: ",request.form.get('checked1', False))
    else:
	    persons=[]
	    personDetails=[]
	    selectPerson=('','user','','','','','','')
	    search_result="user"    
    
    return render_template('search_visitor.html', title='live-visitor', persons=persons,selectPerson=selectPerson,personDetails=personDetails,search_result=search_result)
    

@app.route("/train_vistor", methods=['GET', 'POST'])
def train_vistor():
    global persons,checkList,selectPerson,visitors
    if request.method == 'POST':
        # print(request.form.getlist('checked'))
        checkeds=request.form.getlist('checked')
        checkList=[0]*(len(persons)+1)
        for i in checkeds:
            checkList[int(i)]=1
        if len(checkeds)==1:
            selectPerson=persons[int(checkeds[0])-1]
        # print(int(request.form['action']))
        if request.form['action']=="submit":
            if request.form['selectionVisitor']:
                if selectPerson[0]!='':
                    lstPersonId=[]
                    for ch in checkeds:
                        id=persons[int(ch)-1][0]
                        if id != selectPerson[0]:
                            lstPersonId.append(id)

                    
                    db=Db()
                    visitor_indx=int(request.form['selectionVisitor'])-1
                    slp=list(selectPerson)
                    slp[1]=visitors[visitor_indx][1]
                    slp[2]=visitors[visitor_indx][0]
                    print(slp)
                    db.person_labelling(lstPersonId,slp)
                    persons=db.get_persons(0)
                    # print(persons)
                    checkList=[0]*(len(persons)+1)
                    selectPerson=['','user','','','','','','']
                    
            else:
                print("please select visitor information.")
                print(request.form['action'])
        elif request.form['action']=="checkall":
            checkList=[1]*(len(persons)+1)
        elif request.form['action']=="uncheckall":
            checkList=[0]*(len(persons)+1)
        elif request.form['action']=="clear":
            selectPerson=('','user','','','','','','')
        elif request.form['action']:
            checkList[int(request.form['action'])]=1
            selectPerson=persons[int(request.form['action'])-1]
        

        # print(selectPerson)
            # print(request.form['action'])
        # print("checked: ",request.form.get('checked1', False))
    else:    
        db=Db()
        persons=db.get_persons(0)
        visitors=db.get_visitor_information()
        # for i in range(len(persons)):
        #     persons[i][5]=persons[i][5].timestamp()
        #     persons[i][6]=persons[i][6].timestamp()
            # print(persons[i][6])
        # print(persons)
        checkList=[0]*(len(persons)+1)
        selectPerson=['','user','','','','','','']
    return render_template('train_vistor.html', title='train-vistor', persons=persons,checkList=checkList,selectPerson=selectPerson,visitors=visitors)

btn_visitor_information="Add"
select_visitor_information_indx=''
@app.route("/visitor_information", methods=['GET', 'POST'])
def visitor_information():
    global visitors,selectVisitor,btn_visitor_information,select_visitor_information_indx
    if request.method == 'POST':
        print("post")
        surname=request.form['surname']
        fname=request.form['fname']
        lname=request.form['lname']
        email = request.form['email']
        phone = request.form['phone']
        gender = request.form['gender']
        dob = request.form['dob']
        address = request.form['address']
        trained = False
        status = True
        selectVisitor=(selectVisitor[0],surname,fname,lname,email,phone,gender,dob,address,trained,status)
        if request.form['action']=="Add":
            # print("Add")
            
            vistor_info=(surname,fname,lname,email,phone,gender,dob,address,trained,status)
            # print(vistor_info)
            if surname!="":
                            
                db=Db()
                db.insert_visitor_information(vistor_info)
                visitors=db.get_visitor_information()
                select_visitor_information_indx=len(visitors)-1
                selectVisitor=visitors[select_visitor_information_indx]
                btn_visitor_information="Update"
                
        elif request.form['action']=="Update":
            if surname!="" and selectVisitor[0]!="":

                vistor_info=(fname,lname,email,phone,gender,dob,address,trained,status,selectVisitor[0])            
                db=Db()
                db.update_visitor_information(vistor_info)
                visitors=db.get_visitor_information()
                selectVisitor=visitors[select_visitor_information_indx]
        elif request.form['action']=="Clear":
            selectVisitor=('','','','','','','Male','','','')
            btn_visitor_information="Add"
            select_visitor_information_indx=''
        elif request.form['action']:
            select_visitor_information_indx=int(request.form['action'])-1
            selectVisitor=visitors[select_visitor_information_indx]
            print(selectVisitor[8])
            btn_visitor_information="Update"

        

    else:    
        db=Db()
        visitors=db.get_visitor_information()
        selectVisitor=('','','','','','','Male','','','')
        
    return render_template('visitor_information.html', title='visitor-information', visitors=visitors,selectVisitor=selectVisitor,btn_visitor_information=btn_visitor_information)
selected_image="user"
indx=0
face_encoding=''
unique_ids=[]
nid_check=False
hiddenDiv='hidden'
hiddenBtn=''
@app.route("/visitor_train_by_nid", methods=['GET', 'POST'])
def visitor_train_by_nid():
    global hiddenDiv,hiddenBtn,persons,selectVisitor,btn_visitor_information,select_visitor_information_indx,selected_image,indx,face_encoding,unique_ids,nid_check
    resultMsg=["No Image Find.","No Face Find.","Multiple Face Find.","This Face Already Trained.","Mach Face But Not Trained by NID.","Face Not Mach."]
    if request.method == 'POST':
        
        
        fname=request.form['fname']
        lname=request.form['lname']
        faname=request.form['faname']
        moname=request.form['moname']
        nid=request.form['nid']
        email = request.form['email']
        phone = request.form['phone']
        gender = request.form['gender']
        dob = request.form['dob']
        bloodgroup = request.form['bloodgroup']
        address = request.form['address']
        trained = False
        status = True
        print("post")
        selectVisitor=('',fname,lname,faname,moname,nid,email,phone,gender,dob,bloodgroup,address,status)
        if request.form['action']=="ShowDiv":
            hiddenDiv=''
            hiddenBtn='hidden'
           
        elif request.form['action']=="Hide":
            hiddenDiv='hidden'
            hiddenBtn=''
        elif request.form['action']=="PhotoLoad":
            # print("Add")
            # check if the post request has the file part
            if 'file' not in request.files:
                flash('No file part')
            else:
                file = request.files['file']
                # if user does not select file, browser also
                # submit a empty part without filename
                if file.filename == '':
                    flash('No selected file')
                    
                elif file and allowed_file(file.filename):
                    filename = secure_filename(file.filename)
                    selected_image=str(uuid.uuid4())
                    file.save("static/assets/img/tmp/"+selected_image+".png")
                    # selectVisitor=('','','','','','','','Male','','','')
                    # rec=Recognition()
                    # indx,face_encoding,unique_ids=rec.train_by_nid("static/assets/img/tmp/"+selected_image+".png")
                    # flash(resultMsg[indx])
                    if len(persons)>0:
                        db=Db()
                        persons=db.get_list_of_persons(unique_ids)

        elif request.form['action']=="CheckNID":
            # print("Add")
            # check if the post request has the file part
            if (len(nid)!=17 and len(nid)!=13 and len(nid)!=10) or nid.isdigit()==False:
                flash("NID: "+nid+" is not valid.")
                nid_check=False
            else:
                db=Db()
                visitors=db.check_nid(nid)
                if len(visitors)==0:
                    flash("NID: "+nid+" is not trained.")
                    nid_check=True
                else:
                    nid_check=False

        elif request.form['action']=="Add":
            # print("Add")
            # check if the post request has the file part
            # 1. Insert VisitorInformation
            # 2. INsert PersonInformation
            # 3. INsert Face Encode
            # 4. Visitor marging...
            checkeds=request.form.getlist('checked')
            lstPersonId=[]
            for ch in checkeds:
                id=persons[int(ch)-1][0]                
                lstPersonId.append(id)

            # fname,lname,father_name,mother_name,nid,email,phone,gender,blood_group,dob,address,status
            vistor_info=(fname,lname,faname,moname,nid,email,phone,gender,bloodgroup,dob,address,status)
            # print(vistor_info)
            if fname!="" and nid!="" and (indx==4 or indx==5) and nid_check==True:
                            
                db=Db()
                # step 1
                visitorId=db.insert_visitor_information(vistor_info)
                first_time=time.time()
                # Step 2
                personInfo=('+person_name',visitorId,first_time,first_time,0,0,1)
                person_id_,person_name=db.insert_person_info(personInfo)

                # Step 3
                new_quary_lst=[]
                faceString = face_encoding.tostring()
                new_quary=(faceString,person_id_,1)
                new_quary_lst.append(new_quary)
                db.insert_face_encode(new_quary_lst)

                # Step 4 if mach train face but not labelling face.
                # Marging........
                if len(lstPersonId)>0:
                    db.person_marge(lstPersonId,person_id_)
                
                btn_visitor_information="Update"
                
        elif request.form['action']=="Update":
            if fname!="" and nid!="" and visitorId!="":

                vistor_info=(fname,lname,faname,moname,nid,email,phone,gender,bloodgroup,dob,address,status,visitorId)
                            
                db=Db()
                db.update_visitor_information(vistor_info)
                
        elif request.form['action']=="Clear":
            selectVisitor=('','','','','','','','','Male','','','','')
            btn_visitor_information="Add"
            select_visitor_information_indx=''
        # elif request.form['action']:
        #     select_visitor_information_indx=int(request.form['action'])-1
        #     selectVisitor=visitors[select_visitor_information_indx]
        #     print(selectVisitor[8])
        #     btn_visitor_information="Update"

        

    else:    
        persons=[]
        selectVisitor=('','','','','','','','','Male','','','','')
        selected_image="user"
        # print("un:",uuid.uuid4())
        
    return render_template('visitor_train_by_nid.html', title='visitor-information',hiddenBtn=hiddenBtn,selected_image=selected_image, persons=persons,selectVisitor=selectVisitor,btn_visitor_information=btn_visitor_information,hiddenDiv=hiddenDiv)

@app.route("/live_visitor", methods=['GET', 'POST'])
def live_visitor():
    global persons,checkList,selectPerson,personDetails
    
    if request.method == 'POST':
        # print(request.form.getlist('checked'))
        
        if request.form['action']:
            db=Db()

            selectPerson=persons[int(request.form['action'])-1]
            pt=db.select_person_details_by_person_id(selectPerson[1])

            personDetails=[]
            for p in pt:
                pl=list(p)
                pl[4]=datetime.fromtimestamp(pl[4])
                pl[5]=datetime.fromtimestamp(pl[5])
                dur=pl[5]-pl[4]
                pl[6]=str(timedelta(seconds=dur.seconds))
                personDetails.append(pl)
        

        # print(selectPerson)
            # print(request.form['action'])
        # print("checked: ",request.form.get('checked1', False))
    else:    
        db=Db()
        pt=db.get_live_visitors()
        persons=[]
        for p in pt:
            pl=list(p)
            # print(len(pl))
            pl[3]=datetime.fromtimestamp(pl[3])
            pl[4]=datetime.fromtimestamp(pl[4])
            pl[8]=datetime.fromtimestamp(pl[8])
            persons.append(pl)
        personDetails=[]
        selectPerson=('','user','','','','','','')
        # print(pr)
        # persons=list(persons)
        # print(persons)
        # for i in range(len(persons)):
        #     print(date.fromtimestamp(persons[i][5]))
        #     persons[i][5]=date.fromtimestamp(persons[i][5])
        #     persons[i][6]=date.fromtimestamp(persons[i][6])
        # print(persons)
        # checkList=[0]*(len(persons)+1)
    return render_template('live_visitor.html', title='live-visitor', persons=persons,selectPerson=selectPerson,personDetails=personDetails)
    

@app.route("/visit_history", methods=['GET', 'POST'])
def visit_history():
    global persons,checkList,selectPerson,personDetails,visitors
    
    if request.method == 'POST':
        # print(request.form.getlist('checked'))
        if request.form['action']=="Search":
            if request.form['searchdate']:
                searchdate=datetime.strptime(request.form['searchdate'], "%Y-%m-%d")
            else:
                searchdate=datetime(2018, 10, 13, 0, 0)

            if request.form['searchtodate']:
                searchtodate=datetime.strptime(request.form['searchtodate'], "%Y-%m-%d")
            else:
                searchtodate=datetime(2019, 10, 16, 0, 0)
            
            searchdate=time.mktime(searchdate.timetuple()) + searchdate.microsecond / 1E6

            searchtodate=time.mktime(searchtodate.timetuple()) + searchtodate.microsecond / 1E6

            selectionType=request.form['selectionType']
            print(searchdate,searchtodate,selectionType)
            db=Db()
            
            pt=db.search_persons_details(searchdate,searchtodate,selectionType)

            personDetails=[]
            for p in pt:
                pl=list(p)
                pl[4]=datetime.fromtimestamp(pl[4])
                pl[5]=datetime.fromtimestamp(pl[5])
                dur=pl[5]-pl[4]
                pl[6]=str(timedelta(seconds=dur.seconds))
                personDetails.append(pl)

    else:    
        searchdate=datetime(2018, 10, 13, 0, 0)
        searchtodate=datetime(2019, 10, 16, 0, 0)
        searchdate=time.mktime(searchdate.timetuple()) + searchdate.microsecond / 1E6

        searchtodate=time.mktime(searchtodate.timetuple()) + searchtodate.microsecond / 1E6

        selectionType="All"
        # print(searchdate,searchtodate,selectionType)
        db=Db()
        
        pt=db.search_persons_details(searchdate,searchtodate,selectionType)

        personDetails=[]
        for p in pt:
            pl=list(p)
            pl[4]=datetime.fromtimestamp(pl[4])
            pl[5]=datetime.fromtimestamp(pl[5])
            dur=pl[5]-pl[4]
            pl[6]=str(timedelta(seconds=dur.seconds))
            personDetails.append(pl)

    return render_template('visit_history.html', title='visit-history', selectPerson=selectPerson,personDetails=personDetails,visitors=visitors)
    

@app.route("/setting_camera")
def setting_camera():
    return render_template('setting_camera.html', title='setting-camera')

@app.route("/setting_storage")
def setting_storage():
    return render_template('setting_storage.html', title='setting-storage')

@app.route("/setting_user")
def setting_user():
    return render_template('setting_user.html', title='setting-user')

@app.route("/view_profile")
def view_profile():
    return render_template('view_profile.html', title='view-profile')

@app.route("/visitor_entry")
def visitor_entry():
    return render_template('visitor_entry.html', title='visitor-entry')



if __name__ == '__main__':
    app.run(debug=True, threaded=True,host= '0.0.0.0')
