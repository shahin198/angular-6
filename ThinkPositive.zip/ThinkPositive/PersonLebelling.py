from flask_wtf import FlaskForm
from wtforms import StringField, IntField,FloatField,BooleanField, SubmitField
from wtforms.validators import DataRequired, Length

class Labelling(FlaskForm):
    """docstring for Labelling"""
    def __init__(self, arg):
        super(Labelling, self).__init__()
        self.arg = arg
        self.id= IntField('Id')
        self.id= IntField('Id')
        self.name = StringField('Name', validators=[DataRequired(),Length(min=2,max=20)])
        self.address = StringField('Address', validators=[DataRequired(),Length(min=2,max=20)])
        self.submit=SubmitField('Submit')
        

