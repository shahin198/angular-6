#!/usr/bin/python
import cv2
import time
 
import sqlite3
from sqlite3 import Error
import numpy as np

class Db():
    # Constructor...
    def __init__(self):
        
        database = "recognition_db.db"
        try:
            self.conn = sqlite3.connect(database)
            print(sqlite3.version)
            
        except Error as e:
            print(e)


    def insert_face_encode(self, faceInfoLst):
        """
        Create a new faceInfo        
        :param personInfo:
        :return:
        """
        
        sql = ''' INSERT INTO tblFaceEncode(encode_value,person_id,status)
                  VALUES(?,?,?) '''
        if self.conn is not None:
            for faceInfo in faceInfoLst:
                cur = self.conn.cursor()
                cur.execute(sql, faceInfo)
            self.conn.commit()
            
        else:
            print("insert faild")

        return True

    def update_face_encode(self, faceInfo):
        """

        :param faceInfo:
        :return:  face_id
        """
        sql = ''' UPDATE tblFaceEncode
                  SET person_id = ? ,
                      status = ?
                  WHERE face_id = ?'''
        if self.conn is not None:
            cur = self.conn.cursor()
            cur.execute(sql, faceInfo)
            self.conn.commit()
#             self.get_persons(0)
        else:
            print("Update faild")

    def get_all_face_encode(self):
        
        """        
        :param labelling:
        :return:
        """
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM tblFaceEncode WHERE status=1")
        
        rows_ = cur.fetchall()
        known_face_encodings=[]
        known_face_keys=[]
        known_face_values=[]
        print("rows")
        for row in rows_:
            # print("hello......")
            # face encodings
            y = np.fromstring(row[1])
            # print(y)
            known_face_encodings.append(y)
            # face id
            known_face_keys.append(row[0])
            # print("dd-",row[2])
            # person_id
            known_face_values=np.append(known_face_values,[row[2]])
        # print(known_face_values)

        return known_face_encodings,known_face_keys,known_face_values
    def select_person_face_encode_by_person_id(self, person_id):
        
        """       
        :param priority:
        :return:
        """
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM tblFaceEncode WHERE person_id=?", (person_id,))
        # print(person_id)
        rows = cur.fetchall()       

        return rows
    def update_face_encode_for_marge(self, faceInfo):
        """

        :param faceInfo:
        
        """
        sql = ''' UPDATE tblFaceEncode
                  SET person_id = ? 
                  WHERE face_id = ?'''
        cur = self.conn.cursor()
        cur.execute(sql, faceInfo)
        self.conn.commit()

    # Create Table
    def create_table(self, create_table_sql):
        """ create a table from the create_table_sql statement
        :param conn: Connection object
        :param create_table_sql: a CREATE TABLE statement
        :return:
        """
        try:
            c = self.conn.cursor()
            c.execute(create_table_sql)
        except Error as e:
            print(e)   
            
    def get_persons(self, labelling):
        
        """        
        :param labelling:
        :return:
        """
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM tblPersonInfo WHERE labelling=? AND status=1", (labelling,))
        
        rows = cur.fetchall()
        # print(rows)

        return rows

    

    def get_list_of_persons(self, person_ids):
        
        """        
        :param labelling:
        :return:
        """
        cur = self.conn.cursor()
        qr=""
        j=0
        for i in person_ids:
            qr=qr+str(i)
            j=j+1
            if j<len(person_ids):
                qr=qr+","


        qur="SELECT * FROM tblPersonInfo WHERE person_id in ("+qr+") AND status=1"
        cur.execute(qur)
        
        rows = cur.fetchall()
        print(rows)

        return rows

    def get_all_persons(self):
        
        """        
        :param labelling:
        :return:
        """
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM tblPersonInfo WHERE status=1")
        
        rows = cur.fetchall()
        # print(rows)

        return rows

    def get_live_visitors(self):
        
        """        
        :param labelling:
        :return:
        """
        date=time.time()-200
        cur = self.conn.cursor()
        
        cur.execute("SELECT pi.*,pd.session_end FROM tblPersonInfo pi  INNER JOIN  tblPersonDetails pd ON pi.person_id=pd.person_id  WHERE  pd.session_end > ? AND pi.status=1", (date,))        
        

        rows = cur.fetchall()
        # print(rows)

        return rows

    def select_personInfo_by_person_id(self, person_id):
        
        """       
        :param priority:
        :return:
        """
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM tblPersonInfo WHERE person_id=?", (person_id,))
        # print(person_id)
        rows = cur.fetchall()

        for row in rows:
            # print(row)
            return row

        return None

    def select_persons_order_by_last_time(self):
        """    
        :param conn: the Connection object
        :param priority:
        :return:
        """
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM tblPersonInfo ORDER BY last_time ASC LIMIT 6")

        rows = cur.fetchall()

        return rows

    def insert_person_info(self, personInfo):
        """
        Create a new personInfo        
        :param personInfo:
        :return:
        """
        # print(personInfo)
        sql = ''' INSERT INTO tblPersonInfo(name,visitor_information_id,first_time,last_time,marge_id,labelling,status)
                  VALUES(?,?,?,?,?,?,?) '''
        if self.conn is not None:
            cur = self.conn.cursor()
            cur.execute(sql, personInfo)
            person_id=cur.lastrowid
            self.conn.commit()
            
            person_name="+Person-"+str(person_id)
            person_info=(person_name,personInfo[1],personInfo[3],personInfo[4],personInfo[5],personInfo[6],person_id)
            self.update_person_info(person_info)
            
        else:
            print("insert faild")
            return 0,""

        return person_id,person_name

    def update_person_info(self, personInfo):
        """

        :param personInfo:
        :return:  id
        """
        sql = ''' UPDATE tblPersonInfo
                  SET name = ? ,
                      visitor_information_id = ? ,
                      last_time = ? ,
                      marge_id = ? ,
                      labelling = ? ,
                      status = ?
                  WHERE person_id = ?'''
        if self.conn is not None:
            cur = self.conn.cursor()
            cur.execute(sql, personInfo)
            self.conn.commit()
#             self.get_persons(0)
        else:
            print("Update faild")
        
    def insert_person_details(self, personDetails):
        """
        Create a new personDetails        
        :param personDetails:
        :return:
        """

        sql = ''' INSERT INTO tblPersonDetails(person_id,initial_person_id,camera_id,session_start,session_end,status)
                  VALUES(?,?,?,?,?,?) '''
        cur = self.conn.cursor()
        cur.execute(sql, personDetails)
        self.conn.commit()

        return True

    def update_person_details_for_marge(self, personDetails):
        """

        :param personDetails:
        :return:  id
        """
        sql = ''' UPDATE tblPersonDetails
                  SET person_id = ? ,
                      initial_person_id = ? ,
                      status = ?
                  WHERE id = ?'''
        cur = self.conn.cursor()
        cur.execute(sql, personDetails)
        self.conn.commit()
    
    def update_person_details(self, personDetails):
        """

        :param personDetails:
        :return:  id
        """
        sql = ''' UPDATE tblPersonDetails
                  SET session_end =?
                  WHERE id = ?'''
        cur = self.conn.cursor()
        cur.execute(sql, personDetails)
        self.conn.commit()
    
    
      
    
    def select_person_details_by_person_id(self, person_id):
        
        """       
        :param priority:
        :return:
        """
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM tblPersonDetails WHERE person_id=?", (person_id,))
        # print(person_id)
        rows = cur.fetchall()       

        return rows
    
    def select_person_details_by_person_id_with_camera_id(self, person_id,camera_id):
        
        """       
        :param priority:
        :return:
        """
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM ( SELECT * FROM tblPersonDetails WHERE person_id=? AND camera_id=?) ORDER BY session_end DESC LIMIT 1", (person_id,camera_id))
#         print(person_id)
        rows = cur.fetchall()
#         print(row)
#         print(row[0])
        for row in rows:
            # print(row)
            return row

        return None
    def search_persons_details(self, date,todate,type):
        
        """        
        :param labelling:
        :return:
        """
        cur = self.conn.cursor()
        if type=="All":
            cur.execute("SELECT pd.id,pd.person_id,pd.initial_person_id,pd.camera_id,pd.session_start,pd.session_end,pd.status, pi.name FROM tblPersonDetails pd LEFT JOIN  tblPersonInfo pi ON pi.person_id=pd.person_id  WHERE  pd.session_start BETWEEN ? AND ? AND pd.status=1", (date,todate,))        
        elif type=="Known":
            cur.execute("SELECT pd.id,pd.person_id,pd.initial_person_id,pd.camera_id,pd.session_start,pd.session_end,pd.status, pi.name FROM tblPersonDetails pd LEFT JOIN  tblPersonInfo pi ON pi.person_id=pd.person_id  WHERE  pd.session_start BETWEEN ? AND ? AND pi.labelling=1 AND pd.status=1", (date,todate,))
        elif type=="Unknown":
            cur.execute("SELECT pd.id,pd.person_id,pd.initial_person_id,pd.camera_id,pd.session_start,pd.session_end,pd.status, pi.name FROM tblPersonDetails pd LEFT JOIN  tblPersonInfo pi ON pi.person_id=pd.person_id  WHERE  pd.session_start BETWEEN ? AND ? AND pi.labelling=0 AND pd.status=1", (date,todate,))
        elif type!="":
            cur.execute("SELECT pd.id,pd.person_id,pd.initial_person_id,pd.camera_id,pd.session_start,pd.session_end,pd.status, pi.name FROM tblPersonDetails pd LEFT JOIN  tblPersonInfo pi ON pi.person_id=pd.person_id  WHERE  pd.session_start BETWEEN ? AND ? AND pd.person_id=? AND pd.status=1", (date,todate,type,))
        
        rows = cur.fetchall()
        # print(rows)

        return rows
    def insert_details(self,person_id,camera_id):
        
        session_end=time.time()
        stayDuration=100
        personDetail=self.select_person_details_by_person_id_with_camera_id(person_id,camera_id)
        
        if personDetail==None or session_end-personDetail[5]>stayDuration:
            # person_id,initial_person_id,camera_id,session_start,session_end,status            
            personDetail=(person_id,0,camera_id,session_end,session_end,1)
            self.insert_person_details(personDetail)
        else:
            personDetail=(session_end,personDetail[0])
            self.update_person_details(personDetail)
      
    
    def person_details_marge(self,person_id,marge_id):
        
        person_info=self.select_personInfo_by_person_id(person_id)
#         'name_updated','visitor_information_id','last_time',marge_id,labelling,status,person_id
        personInfo=(person_info[1],person_info[2],person_info[4],marge_id,person_info[6],0,person_info[0])
        self.update_person_info(personInfo)
        
        # update person details
        person_details=self.select_person_details_by_person_id(person_id)
        
        for detail in person_details:            
#             person_id = ? ,initial_person_id = ? ,status = ? id
            personDetail=(marge_id,person_id,detail[6],detail[0])
            self.update_person_details_for_marge(personDetail)

        # update face encodings
        person_face_encodes=self.select_person_face_encode_by_person_id(person_id)
        print("Error: ",person_id,marge_id)
        for face_encode in person_face_encodes:            
#             faceInfo=(9,744)
            faceInfo=(marge_id,face_encode[0])
            print(faceInfo)
            self.update_face_encode_for_marge(faceInfo)

    def person_marge_with_lst(self,unique_id,lst_ids):

        cur = self.conn.cursor()
        qr=""
        j=0
        for i in lst_ids:
            qr=qr+str(i)
            j=j+1
            if j<len(lst_ids):
                qr=qr+","

        
        qur="SELECT person_id, cnt FROM ( SELECT  count(person_id) as cnt,person_id FROM (SELECT * FROM tblPersonDetails WHERE person_id in ("+qr+")  AND status=1) group by person_id) ORDER BY  cnt DESC  limit 1"
        cur.execute(qur)
        rows = cur.fetchall()
        id=0
        for row in rows:
            id=row[0]
            break
        # print("unid: ",unique_id)
        # if id==0:
        #     qur="SELECT person_id, cnt FROM ( SELECT  count(person_id) as cnt,person_id FROM (SELECT * FROM tblPersonDetails WHERE person_id in ("+qr+")  AND status=1) group by person_id) ORDER BY  cnt DESC  limit 1"
        #     cur.execute(qur)
        #     rows = cur.fetchall()
        #     for row in rows:
        #         id=row[0]
        if id==0:
            id=unique_id

        
        # lst_ids.remove(id)    
        for person_id in lst_ids:
            if id != person_id:
                self.person_details_marge(person_id,id)

        return id

    def person_labelling(self,person_ids,person_info):

        print("Person ids:",person_ids)
        print("person_info: ",person_info)

          # 'name_updated','visitor_information_id','last_time',marge_id,labelling,status,person_id
        personInfo=(person_info[1],person_info[2],person_info[4],0,1,person_info[7],person_info[0])
        self.update_person_info(personInfo)
        for person_id in person_ids:
            self.person_details_marge(person_id,person_info[0])

    def person_marge(self,person_ids,select_person_id):
        
        for person_id in person_ids:
            self.person_details_marge(person_id,select_person_id)

    # visitor_information database.....................
    def insert_visitor_information(self, visitorInfo):
        """
        Create a new visitorInfo        
        :param visitorInfo:
        :return:
        """
        
        sql = ''' INSERT INTO tblVisitorInformation(fname,lname,father_name,mother_name,nid,email,phone,gender,blood_group,dob,address,status)
                  VALUES(?,?,?,?,?,?,?,?,?,?,?,?) '''
        if self.conn is not None:
            cur = self.conn.cursor()
            cur.execute(sql, visitorInfo)
            self.conn.commit()
            
        else:
            print("insert faild")

        return True

    def update_visitor_information(self, visitorInfo):
        """

        :param visitorInfo:
        :return:  id
        """
        sql = ''' UPDATE tblVisitorInformation
                  SET fname = ?,
                      lname = ?,
                      father_name = ?,
                      mother_name = ?,
                      nid = ?,
                      email = ?,
                      phone = ?,
                      gender = ?,                      
                      blood_group = ?,
                      dob = ?,
                      address = ?,
                      status = ?
                  WHERE id = ?'''
        if self.conn is not None:
            cur = self.conn.cursor()
            cur.execute(sql, visitorInfo)
            self.conn.commit()
#             self.get_persons(0)
        else:
            print("Update faild")

    def get_visitor_information(self):
        
        """        
        :param labelling:
        :return:
        """
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM tblVisitorInformation WHERE status=1")
        
        rows = cur.fetchall()
        # print(rows)

        return rows

    def get_visitor_information_by_id(self, person_id):
        
        """       
        :param priority:
        :return:
        """
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM tblPersonInfo WHERE person_id=?", (person_id,))
        # print(person_id)
        rows = cur.fetchall()

        for row in rows:
            # print(row)
            return row

        return None

    def check_trained_nid(self, unique_ids):
        
        """       
        :param priority:
        :return:
        """
        cur = self.conn.cursor()
        qr=""
        j=0
        for i in unique_ids:
        	qr=qr+str(i)
        	j=j+1
        	if j<len(unique_id):
        		qr=qr+","

        cur.execute("SELECT * FROM tblPersonInfo WHERE person_id in ("+qr+") AND labelling=1 AND status=1")
        # print(person_id)
        rows = cur.fetchall()        

        return rows

    def check_nid(self, nid):
        
        """       
        :param priority:
        :return:
        """
        cur = self.conn.cursor()
        

        cur.execute("SELECT * FROM tblVisitorInformation WHERE nid=?", (nid,))
        # print(person_id)
        rows = cur.fetchall()        

        return rows

    # Create Database.......
    def createDb(self):
        
        
        personInfo_table = """ CREATE TABLE IF NOT EXISTS tblPersonInfo (
                                            person_id INTEGER PRIMARY KEY AUTOINCREMENT,
                                            name text NOT NULL,
                                            visitor_information_id integer,                                            
                                            first_time float,
                                            last_time float,
                                            marge_id integer,
                                            labelling bool NOT NULL,
                                            status bool NOT NULL
                                        ); """
        person_Details_table = """ CREATE TABLE IF NOT EXISTS tblPersonDetails (
                                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                                            person_id integer NOT NULL,
                                            initial_person_id integer NOT NULL,
                                            camera_id integer NOT NULL,
                                            session_start float,
                                            session_end float,
                                            status bool NOT NULL
                                        ); """

        nid_information_table = """ CREATE TABLE IF NOT EXISTS tblVisitorInformation (
                                            id INTEGER PRIMARY KEY AUTOINCREMENT,                                            
                                            fname text NOT NULL,
                                            lname text,
                                            father_name text,
                                            mother_name text,
                                            nid text,
                                            email text,
                                            phone text,
                                            gender text NOT NULL,
                                            blood_group text,
                                            dob date,
                                            address text,
                                            status bool NOT NULL
                                        ); """

        face_encode_table = """ CREATE TABLE IF NOT EXISTS tblFaceEncode (
                                            face_id INTEGER PRIMARY KEY AUTOINCREMENT,
                                            encode_value text NOT NULL,
                                            person_id integer NOT NULL,                                            
                                            status bool NOT NULL
                                        ); """

        if self.conn is not None:        
            # create person info table
            self.create_table(personInfo_table)
            self.create_table(person_Details_table)
            self.create_table(nid_information_table)
            self.create_table(face_encode_table)

        else:
            print("Error! cannot create the database connection.")

    